
import os
from einops import rearrange
import torch
import torch.nn as nn
import torch.nn.functional as F
from functools import partial
import numpy as np

from timm.models.layers import DropPath, to_2tuple, trunc_normal_
from timm.models.registry import register_model
from timm.models.vision_transformer import _cfg

from pytorch_wavelets import DWTForward
from torchsummary import summary

from torch.autograd import Variable
from torch.nn import  LayerNorm

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.ops.carafe import normal_init, xavier_init, carafe
from torch.utils.checkpoint import checkpoint
import warnings
import numpy as np


class decode(nn.Module):
    def __init__(self, in_channel_left, in_channel_down, out_channel,norm_layer=nn.BatchNorm2d):
        super(decode, self).__init__()
        self.conv_d1 = nn.Conv2d(in_channel_down, out_channel, kernel_size=3, stride=1, padding=1)
        self.conv_l = nn.Conv2d(in_channel_left, out_channel, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv2d(out_channel*2, out_channel, kernel_size=3, stride=1, padding=1)
        self.bn3 = norm_layer(out_channel)

    def forward(self, left, down):
        down_mask = self.conv_d1(down)
        left_mask = self.conv_l(left)
        if down.size()[2:] != left.size()[2:]:
            down_ = F.interpolate(down, size=left.size()[2:], mode='bilinear')
            z1 = F.relu(left_mask * down_, inplace=True)
        else:
            z1 = F.relu(left_mask * down, inplace=True)

        if down_mask.size()[2:] != left.size()[2:]:
            down_mask = F.interpolate(down_mask, size=left.size()[2:], mode='bilinear')

        z2 = F.relu(down_mask * left, inplace=True)

        out = torch.cat((z1, z2), dim=1)
        return F.relu(self.bn3(self.conv3(out)), inplace=True)


class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()

        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        return x

class InteractiveModule(nn.Module):
    def __init__(self, in_channel, out_channel,norm_layer=nn.BatchNorm2d):
        super(InteractiveModule, self).__init__()
        self.convl1 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1)
        self.convl2 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1)
        self.convs1 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1)
        self.convs2 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1)
        self.convl = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1)
        self.convs = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1)


    def forward(self, l, s):

        s_ = F.interpolate(s, size=l.size()[2:], mode='bilinear')
        s1_ = self.convs1(s_)
        l1_ = self.convl1(l)

        s2_ = self.convs2(s_)
        l2_ = self.convl2(l)

        sum1_ = s1_ + l1_
        sig1_1 = torch.sigmoid(sum1_)
        en1 = l2_ * sig1_1
        sig1_2 = torch.sigmoid(en1)
        in1 = (1 - sig1_2) * s_
        

        sum2_ = s2_ + l2_
        sig2_1 = torch.sigmoid(sum2_)
        en2 = s2_ * sig2_1
        sig2_2 = torch.sigmoid(en2)
        in2 = (1 - sig2_2) * l

        inter1 = sig1_2 * en2
        inter2 = sig2_1 * en1

        output1 = in1 + inter1
        output2 = in2 + inter2
        final_output = output1 + output2
       
        return final_output

class GraphConvLayer(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(GraphConvLayer, self).__init__()
        self.linear = nn.Linear(in_channels, out_channels)

    def forward(self, x, adj):
        support = self.linear(x)
        out = torch.bmm(adj, support)
        return out


class GraphConvFeatureEnhancer(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super(GraphConvFeatureEnhancer, self).__init__()
        self.conv1 = GraphConvLayer(in_channels, out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = GraphConvLayer(hidden_channels, out_channels)
    def forward(self, x, adj):
        x = self.conv1(x, adj)
        return x
    
class GraphConv(nn.Module):
    def __init__(self, in_channels):
        super(GraphConv, self).__init__()
        self.in_channels = in_channels


        self.GraphConv2 = GraphConvFeatureEnhancer(in_channels, in_channels // 8, in_channels)
        self.a = False
        self.learnable_adj =  torch.randn(0, 0)
        self.conv_sum = nn.Sequential(nn.Conv2d(in_channels, in_channels, 1))
    def create_adjacency_matrix(self, H, W, device, threshold=0.1):
        adj = nn.Parameter(
                torch.randn(H * W, H * W).normal_(0, 0.01).to(device))
        adj = (adj + adj.t()) / 2
        adj = F.relu(adj)
        D = torch.diag(torch.pow(adj.sum(1), -0.5))
        norm_adj = torch.mm(torch.mm(D, adj), D)

        return norm_adj

    def forward(self, x):

        B, C, H, W = x.shape
        N = H * W

        adj = self.create_adjacency_matrix(H, W, x.device).to(x.device)
        adj = adj.unsqueeze(0).expand(B, -1, -1) 

        x = x.permute(0, 2, 3, 1).reshape(B, N, C)  # (B, H*W, C)
        x = self.GraphConv2(x, adj)
        x = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
        x = self.conv_sum(x)
        return x
    
class Multiscale(nn.Module):
    def __init__(self, in_channel, out_channel, H, W, norm_layer=nn.BatchNorm2d):
        super(Multiscale, self).__init__()
        self.H = H
        self.W = W
        
        self.ac1 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1, dilation=1) 
        self.ac3 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=2, dilation=2)  
        self.ac5 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=3, dilation=3)  
        self.ac7 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=4, dilation=4) 
        self.conv1x1 = nn.Conv2d(out_channel*4, out_channel, kernel_size=1, stride=1, padding=0)
        self.conv3x3 = nn.Conv2d(out_channel, out_channel, kernel_size=1, stride=1, padding=0)

        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        
        self.fc1 = nn.Linear(out_channel, 256)
        self.fc2 = nn.Linear(256, out_channel)

        self.GraphConv = GraphConv(out_channel)
        
    def forward(self, l, s):
        s = F.interpolate(s, size=l.size()[2:], mode='bilinear')
        x = l + s
        x1 = F.relu(self.ac1(x))
        x2 = F.relu(self.ac3(x))
        x3 = F.relu(self.ac5(x))
        x4 = F.relu(self.ac7(x))
        x_ = torch.cat((x1, x2, x3, x4), dim=1)
        x_ = self.conv1x1(x_)

        Graph = self.GraphConv(x_)

        xa = self.avg_pool(x)
        xa = torch.flatten(xa, 1)
        
        xa = F.relu(self.fc1(xa))
        xa = self.fc2(xa)
        xa = F.softmax(xa, dim=1)
        xa = xa.unsqueeze(2).unsqueeze(3)
        
        output = Graph * xa
        output = self.conv3x3(output)
        output = output + x
        
        return output 

class Regression(nn.Module):
    def __init__(self):
        super(Regression, self).__init__()


        self.res1 = nn.Sequential(
            nn.Conv2d(128, 64, 3, padding=1, dilation=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 1, 1),
            nn.ReLU()
        )

        self.c256 = BasicConv2d(512,256,1)
        self.decode1 = InteractiveModule(256,256)
        self.c128 = BasicConv2d(256,128,1)
        self.decode2 = InteractiveModule(128,128)

        self.multiscale = Multiscale(in_channel=128, out_channel=128, H=32,W=32)
        self.init_param()

    def forward(self, x1, x2, x3):

        out1 = self.decode1(x2 , self.c256(x3))
        out = self.decode2(x1 , self.c128(x2))
        # out1 = self.c256(x3)                      #torch.Size([1, 256, 8, 8])
        # out1 = F.interpolate(out1, size=x2.size()[2:], mode='bilinear')   #torch.Size([1, 256, 16, 16])
        # out1 = x2 + out1
        # out = self.c128(x2)    #torch.Size([1, 128, 16, 16])
        # out = F.interpolate(out, size=x1.size()[2:], mode='bilinear')      
        # out = x1 + out


        
        # out1 = F.interpolate(out1, size=out.size()[2:], mode='bilinear')
        out = self.multiscale(out, self.c128(out1))


        y = self.res1(out)

        return y


    def init_param(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight, std=0.01)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)



class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):

        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x





class Attention(nn.Module):
    def __init__(self, dim, num_heads=4, bias=False, ifBox=True):
        super(Attention, self).__init__()
        self.factor = num_heads
        self.ifBox = ifBox
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))        
        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        self.qkv_dwconv = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1, padding=1, groups=dim * 3, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

        self.attn1 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn2 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn3 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn4 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)

    def pad(self, x, factor):
        hw = x.shape[-1]
        t_pad = [0, 0] if hw % factor == 0 else [0, (hw // factor + 1) * factor - hw]
        x = F.pad(x, t_pad, 'constant', 0)
        return x, t_pad

    def unpad(self, x, t_pad):
        _, _, hw = x.shape
        return x[:, :, t_pad[0]:hw - t_pad[1]]

    def softmax_1(self, x, dim=-1):
        logit = x.exp()
        logit = logit / (logit.sum(dim, keepdim=True) + 1)
        return logit

    def normalize(self, x):
        mu = x.mean(-2, keepdim=True)
        sigma = x.var(-2, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5) 

    def reshape_attn(self, q, k, v, h, w):
        b, c, hw = q.shape
        q = q.reshape(b, c, h, w)

        b, c, hw = k.shape
        k = k.reshape(b, c, h, w)

        b, c, hw = v.shape
        v = v.reshape(b, c, h, w)        

        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        _, _, C, _ = q.shape

        mask1 = torch.zeros(b, self.num_heads, C, C, device=q.device, requires_grad=False)
        mask2 = torch.zeros(b, self.num_heads, C, C, device=q.device, requires_grad=False)
        mask3 = torch.zeros(b, self.num_heads, C, C, device=q.device, requires_grad=False)
        mask4 = torch.zeros(b, self.num_heads, C, C, device=q.device, requires_grad=False)

        attn = (q @ k.transpose(-2, -1)) * self.temperature

        index = torch.topk(attn, k=int(C/2), dim=-1, largest=True)[1]
        mask1.scatter_(-1, index, 1.)
        attn1 = torch.where(mask1 > 0, attn, torch.full_like(attn, float('-inf')))

        index = torch.topk(attn, k=int(C*2/3), dim=-1, largest=True)[1]
        mask2.scatter_(-1, index, 1.)
        attn2 = torch.where(mask2 > 0, attn, torch.full_like(attn, float('-inf')))

        index = torch.topk(attn, k=int(C*3/4), dim=-1, largest=True)[1]
        mask3.scatter_(-1, index, 1.)
        attn3 = torch.where(mask3 > 0, attn, torch.full_like(attn, float('-inf')))

        index = torch.topk(attn, k=int(C*4/5), dim=-1, largest=True)[1]
        mask4.scatter_(-1, index, 1.)
        attn4 = torch.where(mask4 > 0, attn, torch.full_like(attn, float('-inf')))

        attn1 = attn1.softmax(dim=-1)
        attn2 = attn2.softmax(dim=-1)
        attn3 = attn3.softmax(dim=-1)
        attn4 = attn4.softmax(dim=-1)

        out1 = (attn1 @ v)
        out2 = (attn2 @ v)
        out3 = (attn3 @ v)
        out4 = (attn4 @ v)

        out = out1 * self.attn1 + out2 * self.attn2 + out3 * self.attn3 + out4 * self.attn4

        out = rearrange(out, 'b head c (h w) -> b (head c) (h w)', head=self.num_heads, h=h, w=w)
        return out

    def forward(self, x, h, w):
        b, n, c = x.shape

        x = x.reshape(b, c, h, w)
        x_sort, idx_h = x[:, :c // 2].sort(-2)
        x_sort, idx_w = x_sort.sort(-1)
        x[:, :c // 2] = x_sort
        qkv = self.qkv_dwconv(self.qkv(x))
        q1, k1, v = qkv.chunk(3, dim=1)  # b,c,x,x        
        v, idx = v.view(b, c, -1).sort(dim=-1)
        q1 = torch.gather(q1.view(b, c, -1), dim=2, index=idx)
        k1 = torch.gather(k1.view(b, c, -1), dim=2, index=idx)
    
        out1 = self.reshape_attn(q1, k1, v, h, w)      
        out1 = torch.scatter(out1, 2, idx, out1).view(b, c, h, w)
        out = self.project_out(out1)
        out_replace = out[:, :c // 2]
        out_replace = torch.scatter(out_replace, -1, idx_w, out_replace)
        out_replace = torch.scatter(out_replace, -2, idx_h, out_replace)
        out[:, :c // 2] = out_replace
        return out.reshape(b, n, c)


class GlobalLocalAttentionBlock(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0., sr_ratio=1):
        super(GlobalLocalAttentionBlock, self).__init__()
        self.attention = Attention(dim, num_heads)
        

    def forward(self, x, H, W):

        global_out = self.attention(x, H, W)
        
        
        return global_out


class Block(nn.Module):

    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, sr_ratio=1):
        super().__init__()
        self.norm1 = norm_layer(dim)
        self.attn = GlobalLocalAttentionBlock(
            dim,
            num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale,
            attn_drop=attn_drop, proj_drop=drop, sr_ratio=sr_ratio,
        )
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
        self.drop_path1 = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.drop_path2 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x, H, W):
        x = x + self.drop_path1(self.attn(self.norm1(x), H, W))
        x = x + self.drop_path2(self.mlp(self.norm2(x)))

        return x



class SBlock(Block):
    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, sr_ratio=1):
        super(SBlock, self).__init__(dim, num_heads, mlp_ratio, qkv_bias, qk_scale, drop, attn_drop,
                                     drop_path, act_layer, norm_layer)

    def forward(self, x, H, W):
        return super(SBlock, self).forward(x)


class GroupBlock(Block):
    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, sr_ratio=1):

        super(GroupBlock, self).__init__(dim, num_heads, mlp_ratio, qkv_bias, qk_scale, drop, attn_drop,
                                       drop_path, act_layer, norm_layer)

        # #delete the qk_scale
        # super(GroupBlock, self).__init__(dim=dim, num_heads=num_heads, mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, proj_drop=drop, attn_drop=attn_drop,
        #                                 drop_path=drop_path, act_layer=act_layer, norm_layer=norm_layer)
        del self.attn

        self.attn = GlobalLocalAttentionBlock(
            dim,
            num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale,
            attn_drop=attn_drop, proj_drop=drop, sr_ratio=sr_ratio,
        )


    def forward(self, x, H, W):
        x = x + self.drop_path1(self.attn(self.norm1(x), H, W))
        x = x + self.drop_path2(self.mlp(self.norm2(x)))

        return x

class PatchEmbed(nn.Module):
    """ Image to Patch Embedding
    """

    def __init__(self, img_size=224, patch_size=16, in_chans=3, embed_dim=768):      #embed_dim表示输出的patch的向量维度
        super().__init__()
        img_size = to_2tuple(img_size)
        patch_size = to_2tuple(patch_size)
        self.img_size = img_size
        self.patch_size = patch_size
        assert img_size[0] % patch_size[0] == 0 and img_size[1] % patch_size[1] == 0, \
            f"img_size {img_size} should be divided by patch_size {patch_size}."
        self.H, self.W = img_size[0] // patch_size[0], img_size[1] // patch_size[1]
        self.num_patches = self.H * self.W
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, x):

        B, C, H, W = x.shape     #torch.Size([1, 3, 256, 256])

        # x = self.proj(x)   # torch.Size([1, 128, 64, 64])
        # x1 = x.flatten(2)    #torch.Size([1, 128, 4096])
        # x2 = x1.transpose(1, 2)    #torch.Size([1, 4096, 128])
        x = self.proj(x).flatten(2).transpose(1, 2)    #torch.Size([1, 4096, 128])每个块（每个像素点）长度都是128
        x = self.norm(x)      #torch.Size([1, 4096, 128])
        H, W = H // self.patch_size[0], W // self.patch_size[1]     #H,W=64,64特征图的大小

        return x, (H, W)


# borrow from PVT https://github.com/whai362/PVT.git
class PyramidVisionTransformer(nn.Module):
    def __init__(self, img_size=224, patch_size=16, in_chans=3, num_classes=1000, embed_dims=[64, 128, 256, 512],
                 num_heads=[1, 2, 4, 8], mlp_ratios=[4, 4, 4, 4], qkv_bias=False, qk_scale=None, drop_rate=0.,
                 attn_drop_rate=0., drop_path_rate=0., norm_layer=nn.LayerNorm,
                 depths=[3, 4, 6, 3], sr_ratios=[8, 4, 2, 1], block_cls=Block):
        super().__init__()
        self.num_classes = num_classes
        self.depths = depths

        # patch_embed
        self.patch_embeds = nn.ModuleList()       #这四行创建模型中各个模块的列表
        self.pos_embeds = nn.ParameterList()
        self.pos_drops = nn.ModuleList()
        self.blocks = nn.ModuleList()

        for i in range(len(depths)):        #使用循环来构建PatchEmbed模块和相关位置嵌入和Dropout操作
            if i == 0:
                self.patch_embeds.append(PatchEmbed(img_size, patch_size, in_chans, embed_dims[i]))
            else:
                self.patch_embeds.append(
                    PatchEmbed(img_size // patch_size // 2 ** (i - 1), 2, embed_dims[i - 1], embed_dims[i]))      #深度越深，图像越小
            patch_num = self.patch_embeds[-1].num_patches + 1 if i == len(embed_dims) - 1 else self.patch_embeds[         #self.patch_embeds[-1]表示前一个PathEnbed实例
                -1].num_patches
            self.pos_embeds.append(nn.Parameter(torch.zeros(1, patch_num, embed_dims[i])))   #代码使用 nn.Parameter 函数将零张量转换为可训练的模型参数
            self.pos_drops.append(nn.Dropout(p=drop_rate))

        #dpr 列表的长度等于 sum(depths)，即所有层的深度之和。每个层都将有一个对应的元素来表示该层的随机深度衰减率。
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]  # stochastic depth decay rule和drop有关训练时随即丢弃某些层

        cur = 0
        for k in range(len(depths)):
            _block = nn.ModuleList([
                block_cls(
                    dim=embed_dims[k], num_heads=num_heads[k], mlp_ratio=mlp_ratios[k], qkv_bias=qkv_bias,
                    qk_scale=qk_scale,
                    drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[cur + i], norm_layer=norm_layer,
                    sr_ratio=sr_ratios[k]
                    )
                for i in range(depths[k])])
            self.blocks.append(_block)
            cur += depths[k]

        self.norm = norm_layer(embed_dims[-1])

        # cls_token
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dims[-1]))

        # classification head
        self.head = nn.Linear(embed_dims[-1], num_classes) if num_classes > 0 else nn.Identity()

        # init weights
        for pos_emb in self.pos_embeds:
            trunc_normal_(pos_emb, std=.02)
        self.apply(self._init_weights)     #apply对各子模块进行初始化

    def reset_drop_path(self, drop_path_rate):
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(self.depths))]
        cur = 0
        for k in range(len(self.depths)):
            for i in range(self.depths[k]):
                self.blocks[k][i].drop_path.drop_prob = dpr[cur + i]
            cur += self.depths[k]

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    @torch.jit.ignore
    def no_weight_decay(self):
        return {'cls_token'}

    def get_classifier(self):
        return self.head

    def reset_classifier(self, num_classes, global_pool=''):
        self.num_classes = num_classes
        self.head = nn.Linear(self.embed_dim, num_classes) if num_classes > 0 else nn.Identity()

    def forward_features(self, x):
        B = x.shape[0]
        for i in range(len(self.depths)):
            x, (H, W) = self.patch_embeds[i](x)
            if i == len(self.depths) - 1:
                cls_tokens = self.cls_token.expand(B, -1, -1)
                x = torch.cat((cls_tokens, x), dim=1)
            x = x + self.pos_embeds[i]
            x = self.pos_drops[i](x)
            for blk in self.blocks[i]:
                x = blk(x, H, W)
            if i < len(self.depths) - 1:
                x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        x = self.norm(x)
        return x[:, 0]

    def forward(self, x):
        x = self.forward_features(x)
        x = self.head(x)

        return x


# PEG  from https://arxiv.org/abs/2102.10882
class PosCNN(nn.Module):
    def __init__(self, in_chans, embed_dim=768, s=1):
        super(PosCNN, self).__init__()
        self.proj = nn.Sequential(nn.Conv2d(in_chans, embed_dim, 3, s, 1, bias=True, groups=embed_dim), )
        self.s = s

    def forward(self, x, H, W):
        B, N, C = x.shape
        feat_token = x    #将x给特征标记
        cnn_feat = feat_token.transpose(1, 2).view(B, C, H, W)    #torch.Size([1, 128, 4096])    [torch.Size([1, 128, 64, 64])]
        if self.s == 1: 
            x = self.proj(cnn_feat) + cnn_feat       #对图像特征进行投影，并与图像特征 cnn_feat 相加
        else:
            x = self.proj(cnn_feat)
        x = x.flatten(2).transpose(1, 2)     #torch.Size([1, 4096, 128])
        return x

    def no_weight_decay(self):
        return ['proj.%d.weight' % i for i in range(4)]


class CPVTV2(PyramidVisionTransformer):
    """
    Use useful results from CPVT. PEG and GAP.
    Therefore, cls token is no longer required.
    PEG is used to encode the absolute position on the fly, which greatly affects the performance when input resolution
    changes during the training (such as segmentation, detection)
    """
    def __init__(self, img_size=224, patch_size=4, in_chans=3, num_classes=1000, embed_dims=[64, 128, 256, 512],
                 num_heads=[1, 2, 4, 8], mlp_ratios=[4, 4, 4, 4], qkv_bias=False, qk_scale=None, drop_rate=0.,
                 attn_drop_rate=0., drop_path_rate=0., norm_layer=nn.LayerNorm,
                 depths=[3, 4, 6, 3], sr_ratios=[8, 4, 2, 1], block_cls=Block):
        super(CPVTV2, self).__init__(img_size, patch_size, in_chans, num_classes, embed_dims, num_heads, mlp_ratios,
                                     qkv_bias, qk_scale, drop_rate, attn_drop_rate, drop_path_rate, norm_layer, depths,
                                     sr_ratios, block_cls)
        del self.pos_embeds
        del self.cls_token
        self.pos_block = nn.ModuleList(
            [PosCNN(embed_dim, embed_dim) for embed_dim in embed_dims]
        )

        self.regression = Regression()
        self.apply(self._init_weights)


    def _init_weights(self, m):
        import math
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels    #计算权重数量
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()
        elif isinstance(m, nn.BatchNorm2d):
            m.weight.data.fill_(1.0)
            m.bias.data.zero_()

    def no_weight_decay(self):
        return set(['cls_token'] + ['pos_block.' + n for n, p in self.pos_block.named_parameters()])

    def forward_features(self, x):
        outputs = list()    #存储每个阶段的输出

        B = x.shape[0]     #批次大小

        for i in range(len(self.depths)):
            x, (H, W) = self.patch_embeds[i](x)     #torch.Size([1, 4096, 128])  (64,64)
            x = self.pos_drops[i](x)
            for j, blk in enumerate(self.blocks[i]):
                x = blk(x, H, W)
                if j == 0:
                    x = self.pos_block[i](x, H, W)
            x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
            outputs.append(x)

        return outputs

    def forward(self, x):
        x = self.forward_features(x)
        mu = self.regression(x[1], x[2], x[3])
        B, C, H, W = mu.size()
        mu_sum = mu.view([B, -1]).sum(1).unsqueeze(1).unsqueeze(2).unsqueeze(3)
        mu_normed = mu / (mu_sum + 1e-6)
        return mu, mu_normed


class PCPVT(CPVTV2):
    def __init__(self, img_size=224, patch_size=4, in_chans=3, num_classes=1000, embed_dims=[64, 128, 256],
                 num_heads=[1, 2, 4], mlp_ratios=[4, 4, 4], qkv_bias=False, qk_scale=None, drop_rate=0.,
                 attn_drop_rate=0., drop_path_rate=0., norm_layer=nn.LayerNorm,
                 depths=[4, 4, 4], sr_ratios=[4, 2, 1], block_cls=Block):
        super(PCPVT, self).__init__(img_size, patch_size, in_chans, num_classes, embed_dims, num_heads,
                                    mlp_ratios, qkv_bias, qk_scale, drop_rate, attn_drop_rate, drop_path_rate,
                                    norm_layer, depths, sr_ratios, block_cls)


class DOTNet(PCPVT):
    """
    alias Twins-SVT
    """
    def __init__(self, img_size=224, patch_size=4, in_chans=3, num_classes=1000, embed_dims=[64, 128, 256],
                 num_heads=[1, 2, 4], mlp_ratios=[4, 4, 4], qkv_bias=False, qk_scale=None, drop_rate=0.,
                 attn_drop_rate=0., drop_path_rate=0., norm_layer=nn.LayerNorm,
                 depths=[4, 4, 4], sr_ratios=[4, 2, 1], block_cls=GroupBlock):
        super(DOTNet, self).__init__(img_size, patch_size, in_chans, num_classes, embed_dims, num_heads,
                                     mlp_ratios, qkv_bias, qk_scale, drop_rate, attn_drop_rate, drop_path_rate,
                                     norm_layer, depths, sr_ratios, block_cls)
        del self.blocks
 
        # transformer encoder
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]  # stochastic depth decay rule
        cur = 0
        self.blocks = nn.ModuleList()
        for k in range(len(depths)):
            _block = nn.ModuleList([block_cls(
                dim=embed_dims[k], num_heads=num_heads[k], mlp_ratio=mlp_ratios[k], qkv_bias=qkv_bias,
                qk_scale=qk_scale,
                drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[cur + i], norm_layer=norm_layer,
                sr_ratio=sr_ratios[k],) for i in range(depths[k])])
            self.blocks.append(_block)
            cur += depths[k]
        self.apply(self._init_weights)


def _conv_filter(state_dict, patch_size=16):
    """ convert patch embedding weight from manual patchify + linear proj to conv"""
    out_dict = {}
    for k, v in state_dict.items():
        if 'patch_embed.proj.weight' in k:
            v = v.reshape((v.shape[0], 3, patch_size, patch_size))
        out_dict[k] = v

    return out_dict

@register_model
def alt_gvt_small(pretrained=False, **kwargs):
    model = DOTNet(
        patch_size=4, embed_dims=[64, 128, 256, 512], num_heads=[2, 4, 8, 16], mlp_ratios=[4, 4, 4, 4], qkv_bias=True,
        norm_layer=partial(nn.LayerNorm, eps=1e-6), depths=[2, 2, 10, 4], wss=[7, 7, 7, 7], sr_ratios=[8, 4, 2, 1],
        **kwargs)
    model.default_cfg = _cfg()
    return model


@register_model
def alt_gvt_base(pretrained=True, **kwargs):
    model = DOTNet(
        patch_size=4, embed_dims=[96, 192, 384, 768], num_heads=[3, 6, 12, 24], mlp_ratios=[4, 4, 4, 4], qkv_bias=True,
        norm_layer=partial(nn.LayerNorm, eps=1e-6), depths=[2, 2, 18, 2], wss=[7, 7, 7, 7], sr_ratios=[8, 4, 2, 1],
        **kwargs)

    model.default_cfg = _cfg()
    return model


@register_model
def alt_gvt_large(pretrained=True,**kwargs):
    model = DOTNet(
        patch_size=4, embed_dims=[64, 128, 256, 512], num_heads=[4, 8, 16, 32], mlp_ratios=[4, 4, 4, 4],
        qkv_bias=True,
        norm_layer=partial(nn.LayerNorm, eps=1e-6), depths=[2, 2, 10, 4], sr_ratios=[8, 4, 2, 1],
        **kwargs)
    model.default_cfg = _cfg()
    if pretrained:
        '''download from https://github.com/Meituan-AutoML/Twins/alt_gvt_large.pth'''
        checkpoint = torch.load(r'C:\Users\ming\Desktop\code\FSGformer(two)\alt_gvt_small.pth') # todo pass path as argument
        model.load_state_dict(checkpoint, strict=False)
        print("load transformer pretrained")
    return model

if __name__ == '__main__':
    model = alt_gvt_large().cuda()
    x = torch.ones(1, 3, 256, 256).cuda() 
    mu, mu_norm = model(x)
    print(mu.size(), mu_norm.size())
#     # print(model)
#     summary(model,input_size=(3,256,256))
    

    