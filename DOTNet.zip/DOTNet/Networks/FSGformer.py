
from einops import rearrange
import torch
import torch.nn as nn
import torch.nn.functional as F
from functools import partial
import numpy as np

from timm.models.layers import DropPath, to_2tuple, trunc_normal_
from timm.models.registry import register_model
from timm.models.vision_transformer import _cfg

from pytorch_wavelets import DWTForward
from torchsummary import summary

from torch.autograd import Variable
from torch.nn import  LayerNorm

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.ops.carafe import normal_init, xavier_init, carafe
from torch.utils.checkpoint import checkpoint
import warnings
import numpy as np

def normal_init(module, mean=0, std=1, bias=0):   #初始化参数
    if hasattr(module, 'weight') and module.weight is not None:
        nn.init.normal_(module.weight, mean, std)
    if hasattr(module, 'bias') and module.bias is not None:
        nn.init.constant_(module.bias, bias)


def constant_init(module, val, bias=0):       #常数初始化
    if hasattr(module, 'weight') and module.weight is not None:
        nn.init.constant_(module.weight, val)
    if hasattr(module, 'bias') and module.bias is not None:
        nn.init.constant_(module.bias, bias)

def resize(input,                             
           size=None,
           scale_factor=None,
           mode='nearest',
           align_corners=None,
           warning=True):                     #缩放
    if warning:
        if size is not None and align_corners:
            input_h, input_w = tuple(int(x) for x in input.shape[2:])
            output_h, output_w = tuple(int(x) for x in size)
            if output_h > input_h or output_w > input_w:
                if ((output_h > 1 and output_w > 1 and input_h > 1
                     and input_w > 1) and (output_h - 1) % (input_h - 1)
                        and (output_w - 1) % (input_w - 1)):
                    warnings.warn(
                        f'When align_corners={align_corners}, '
                        'the output would more aligned if '
                        f'input size {(input_h, input_w)} is `x+1` and '
                        f'out size {(output_h, output_w)} is `nx+1`')
    return F.interpolate(input, size, scale_factor, mode, align_corners)


class Similarity(nn.Module):
    def __init__(self):
        super(Similarity, self).__init__()

    def forward(self, x):
        batch, C, H, W = x.shape
        x = x.permute(0, 2, 3, 1).view(batch, H, W)  # Reshape to (B, H, W)
        x_bar = x.permute(0, 2, 1)  # Transpose (B, W, H)
        sim = torch.bmm(x, x_bar)  # Batch matrix multiplication
        sim = F.normalize(sim, p=2, dim=-1)  # Normalize along the last axis
        sim = sim.unsqueeze(-1).permute(0, 3, 2, 1)  # Add channel dimension
        return sim

class FeatureChange(nn.Module):
    def __init__(self, H, W):
        super(FeatureChange, self).__init__()
        self.lstm_h = nn.LSTM(H, W, batch_first=True, bidirectional=False)
        self.lstm_w = nn.LSTM(W, H, batch_first=True, bidirectional=False)

    def forward(self, x):
        batch, C, H, W = x.shape
        # Reshape for height LSTM
        x_h = x.permute(0, 2, 3, 1).reshape(batch, H, W)
        lstm_h, _ = self.lstm_h(x_h)

        # Reshape for width LSTM
        x_w = x.permute(0, 3, 2, 1).reshape(batch, W, H)
        lstm_w, _ = self.lstm_w(x_w)

        lstm = lstm_h + lstm_w
        lstm = lstm.unsqueeze(-1).permute(0, 3, 2, 1)  # Add channel dimension
        return lstm

class SaFA(nn.Module):
    def __init__(self,in_channel,H,W):
        super(SaFA, self).__init__()
        self.conv1 = nn.Conv2d(in_channel, 256, kernel_size=5, padding=2, groups=1)
        self.conv2 = nn.Conv2d(256, 64, kernel_size=3, padding=1, groups=1)
        self.conv3 = nn.Conv2d(64, 1, kernel_size=1, padding=0, groups=1)
        self.conv4 = nn.Conv2d(in_channel, 256, kernel_size=1, stride=1, padding=0, groups=1)
        self.conv5 = nn.Conv2d(256, 64, kernel_size=3, padding=1, groups=1)
        self.conv6 = nn.Conv2d(64, 1, kernel_size=1, padding=0, groups=1)
        # self.maxpool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)

        self.feature_change = FeatureChange(H, W)  # Adjust H and W as per input size
        self.similarity = Similarity()

    def forward(self, inputs):
        x = F.relu(self.conv1(inputs))
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))

        lstm = self.feature_change(x)
        sim = self.similarity(lstm)
        attn = sim * inputs

        x = F.relu(self.conv4(attn))
        x = F.relu(self.conv5(x))
        x = torch.sigmoid(self.conv6(x))

        # inputs = self.maxpool(inputs)
        x = inputs * x
        return x

class CrossAttention(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(CrossAttention, self).__init__()
        self.conv1 = nn.Sequential(nn.Conv2d(in_channels=in_channel, out_channels=in_channel, kernel_size=3, padding=1, stride=1),
                                   # nn.InstanceNorm2d(in_channel),
                                   nn.ReLU(),
                                   )
        self.conv2 = nn.Sequential(nn.Conv2d(in_channels=in_channel, out_channels=in_channel, kernel_size=3, padding=1, stride=1),
                                   # nn.InstanceNorm2d(in_channel),
                                   nn.ReLU(),
                                   )
    def forward(self, f1, f2):
        f1_hat = f1
        f1 = self.conv1(f1)
        f2 = self.conv2(f2)
        att_map = f1 * f2
        att_shape = att_map.shape
        att_map = torch.reshape(att_map, [att_shape[0], att_shape[1], -1])
        att_map = F.softmax(att_map, dim=2)
        att_map = torch.reshape(att_map, att_shape)
        f1 = f1 * att_map
        f1 = f1 + f1_hat
        return f1


class FusionRegBlk_lite(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(FusionRegBlk_lite, self).__init__()
        self.conv1x1 = nn.Sequential(
            nn.Conv2d(kernel_size=1, stride=1, padding=0, in_channels=in_channel, out_channels=in_channel),
            nn.LeakyReLU())

        self.crossAtt1 = CrossAttention(in_channel, out_channel)

    def forward(self, f1, f2): 

        f1 = self.crossAtt1(f1, f2) 
        f2 = self.crossAtt1(f2, f1) 
        return f1, f2
    

class fusion(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(fusion, self).__init__()
        self.attention_norm = LayerNorm(in_channel, eps=1e-6)
        self.attention_normd = LayerNorm(in_channel, eps=1e-6)
        self.ffn_norm = LayerNorm(in_channel, eps=1e-6)
        self.ffn_normd = LayerNorm(in_channel, eps=1e-6)
        self.attn = FusionRegBlk_lite(in_channel, out_channel)
        self.fc = nn.Sequential(
            nn.Linear(in_channel, int(in_channel / 4), bias=False),  # 压缩
            nn.ReLU(inplace=True),
            nn.Linear(int(in_channel / 4), in_channel, bias=False),  # 恢复
            nn.Sigmoid()
        )


    def forward(self, x, y):
        hx = x
        hy = y

        xb, xc, xh, xw = x.shape
        x = x.permute(0, 2, 3, 1).contiguous().view(xb, -1, xc)  # 转换为 [batch_size * height * width, channels]
        yb, yc, yh, yw = y.shape
        y = y.permute(0, 2, 3, 1).contiguous().view(xb, -1, yc)  # 转换为 [batch_size * height * width, channels]

        x = self.attention_norm(x)
        y = self.attention_normd(y)
                # 恢复原始形状
        x = x.view(xb, xh, xw, xc).permute(0, 3, 1, 2)  # 转换回 [batch, channels, height, width]
        # 恢复原始形状
        y = y.view(yb, yh, yw, yc).permute(0, 3, 1, 2)  # 转换回 [batch, channels, height, width]    
             
        x, y = self.attn(x, y)

        x = x + hx
        y = y + hy

        hx = x
        hy = y

        x = x.permute(0, 2, 3, 1).contiguous().view(xb, -1, xc)  # 转换为 [batch_size * height * width, channels]
        yb, yc, yh, yw = y.shape
        y = y.permute(0, 2, 3, 1).contiguous().view(xb, -1, yc)  # 转换为 [batch_size * height * width, channels]

        x = self.ffn_norm(x)
        y = self.ffn_normd(y)

        x = self.fc(x)
        x = x*x


        y = self.fc(y)
        y = y*y


        x = x.view(xb, xh, xw, xc).permute(0, 3, 1, 2)  # 转换回 [batch, channels, height, width]
        # 恢复原始形状
        y = y.view(yb, yh, yw, yc).permute(0, 3, 1, 2)  # 转换回 [batch, channels, height, width] 

        x = x + hx
        y = y + hy

        out =  x + y

        return out

class UpsampleBlock(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(UpsampleBlock, self).__init__()
        self.up1 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),  # 上采样
            nn.Conv2d(in_channels=in_channel, out_channels=out_channel, kernel_size=1, padding=0, stride=1),  # 1x1 卷积
            nn.LeakyReLU(inplace=True)  # 激活函数
        )
    
    def forward(self, x):
        x = self.up1(x)
        return x
    
class FocalModulation(nn.Module):
    """ Focal Modulation

    Args:
        dim (int): Number of input channels.
        proj_drop (float, optional): Dropout ratio of output. Default: 0.0
        focal_level (int): Number of focal levels
        focal_window (int): Focal window size at focal level 1
        focal_factor (int, default=2): Step to increase the focal window
        use_postln (bool, default=False): Whether use post-modulation layernorm
    """

    def __init__(self, dim, proj_drop=0., focal_level=2, focal_window=7, focal_factor=2, use_postln=False):

        super().__init__()
        self.dim = dim

        # specific args for focalv3
        self.focal_level = focal_level
        self.focal_window = focal_window
        self.focal_factor = focal_factor
        self.use_postln = use_postln

        self.f = nn.Linear(dim, 2*dim+(self.focal_level+1), bias=True)
        self.h = nn.Conv2d(dim, dim, kernel_size=1, stride=1, padding=0, groups=1, bias=True)

        self.act = nn.GELU()
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)
        self.focal_layers = nn.ModuleList()

        if self.use_postln:
            self.ln = nn.LayerNorm(dim)

        for k in range(self.focal_level):
            kernel_size = self.focal_factor*k + self.focal_window
            self.focal_layers.append(
                nn.Sequential(
                    nn.Conv2d(dim, dim, kernel_size=kernel_size, stride=1, groups=dim, 
                        padding=kernel_size//2, bias=False),
                    nn.GELU(),
                    )
                )

    def forward(self, x):

        B, C, nH, nW = x.shape
        x = x.reshape(B, C, -1).permute(0, 2, 1)
        x = self.f(x)
        x = x.permute(0, 2, 1).reshape(B,-1, nH, nW)
        q, ctx, gates = torch.split(x, (C, C, self.focal_level+1), 1)
        
        ctx_all = 0
        for l in range(self.focal_level):                     
            ctx = self.focal_layers[l](ctx)
            ctx_all = ctx_all + ctx*gates[:, l:l+1]
        ctx_global = self.act(ctx.mean(2, keepdim=True).mean(3, keepdim=True))
        ctx_all = ctx_all + ctx_global*gates[:,self.focal_level:]

        x_out = q * self.h(ctx_all)
        x_out = x_out.permute(0, 2, 3, 1).contiguous()
        if self.use_postln:
            x_out = self.ln(x_out)            
        x_out = self.proj(x_out)
        x_out = self.proj_drop(x_out)
        x_out = x_out.permute(0, 3,1, 2)
        return x_out

class decode(nn.Module):
    def __init__(self, in_channel_left, in_channel_down, out_channel,norm_layer=nn.BatchNorm2d):
        super(decode, self).__init__()
        self.conv_d1 = nn.Conv2d(in_channel_down, out_channel, kernel_size=3, stride=1, padding=1)
        self.conv_l = nn.Conv2d(in_channel_left, out_channel, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv2d(out_channel*2, out_channel, kernel_size=3, stride=1, padding=1)
        self.bn3 = norm_layer(out_channel)

    def forward(self, left, down):
        down_mask = self.conv_d1(down)
        left_mask = self.conv_l(left)
        if down.size()[2:] != left.size()[2:]:
            down_ = F.interpolate(down, size=left.size()[2:], mode='bilinear')
            z1 = F.relu(left_mask * down_, inplace=True)
        else:
            z1 = F.relu(left_mask * down, inplace=True)

        if down_mask.size()[2:] != left.size()[2:]:
            down_mask = F.interpolate(down_mask, size=left.size()[2:], mode='bilinear')

        z2 = F.relu(down_mask * left, inplace=True)

        out = torch.cat((z1, z2), dim=1)
        return F.relu(self.bn3(self.conv3(out)), inplace=True)


class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()

        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        return x
##################################
class InteractiveModule(nn.Module):
    def __init__(self, in_channel, out_channel,norm_layer=nn.BatchNorm2d):
        super(InteractiveModule, self).__init__()
        # 定义卷积层
        self.convl1 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1)
        self.convl2 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1)
        self.convs1 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1)
        self.convs2 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1)
        self.convl = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1)
        self.convs = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1)


    def forward(self, l, s):

        s_ = F.interpolate(s, size=l.size()[2:], mode='bilinear')
        s1_ = self.convs1(s_)
        l1_ = self.convl1(l)

        s2_ = self.convs2(s_)
        l2_ = self.convl2(l)

        sum1_ = s1_ + l1_
        sig1_1 = torch.sigmoid(sum1_)
        # l_ = self.convl(l)
        en1 = l2_ * sig1_1
        sig1_2 = torch.sigmoid(en1)
        in1 = (1 - sig1_2) * s_
        

        sum2_ = s2_ + l2_
        sig2_1 = torch.sigmoid(sum2_)
        # s__ = self.convs(s_)
        en2 = s2_ * sig2_1
        sig2_2 = torch.sigmoid(en2)
        in2 = (1 - sig2_2) * l

        inter1 = sig1_2 * en2
        inter2 = sig2_1 * en1

        output1 = in1 + inter1
        output2 = in2 + inter2
        final_output = output1 + output2
       
        return final_output
    ##############################################################

    
    #########################################################################3
class GraphConvLayer(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(GraphConvLayer, self).__init__()
        self.linear = nn.Linear(in_channels, out_channels)

    def forward(self, x, adj):
        # x: 节点特征矩阵 (B, N, in_channels)
        # adj: 邻接矩阵 (N, N)
        support = self.linear(x)
        out = torch.bmm(adj, support)
        return out


class GraphConvFeatureEnhancer(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super(GraphConvFeatureEnhancer, self).__init__()
        self.conv1 = GraphConvLayer(in_channels, out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = GraphConvLayer(hidden_channels, out_channels)
    def forward(self, x, adj):
        x = self.conv1(x, adj)
        # x = self.relu(x)
        # x = self.conv2(x, adj)
        return x
    
class GraphConv(nn.Module):
    def __init__(self, in_channels):
        super(GraphConv, self).__init__()
        self.in_channels = in_channels


        self.GraphConv2 = GraphConvFeatureEnhancer(in_channels, in_channels // 8, in_channels)
        self.a = False
        self.learnable_adj =  torch.randn(0, 0)# Initialize learnable adjacency matrix as None
        self.conv_sum = nn.Sequential(nn.Conv2d(in_channels, in_channels, 1))
    def create_adjacency_matrix(self, H, W, device, threshold=0.1):
        adj = nn.Parameter(
                torch.randn(H * W, H * W).normal_(0, 0.01).to(device))
        # 确保邻接矩阵是对称的
        adj = (adj + adj.t()) / 2
        # 应用非线性激活函数
        adj = F.relu(adj)
        # 稀疏化邻接矩阵
        # with torch.no_grad():
        #     adj[adj < threshold] = 0
        # 归一化邻接矩阵
        D = torch.diag(torch.pow(adj.sum(1), -0.5))
        norm_adj = torch.mm(torch.mm(D, adj), D)

        return norm_adj

    def forward(self, x):
        res_x = x

        B, C, H, W = x.shape
        N = H * W

        adj = self.create_adjacency_matrix(H, W, x.device).to(x.device)  # Use the learnable adjacency matrix
        adj = adj.unsqueeze(0).expand(B, -1, -1)  # Expand to match batch size

        x = x.permute(0, 2, 3, 1).reshape(B, N, C)  # (B, H*W, C)
        x = self.GraphConv2(x, adj)
        x = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
        x = self.conv_sum(x)
        return x
    
class Multiscale(nn.Module):
    def __init__(self, in_channel, out_channel, H, W, norm_layer=nn.BatchNorm2d):
        super(Multiscale, self).__init__()
        self.H = H
        self.W = W
        
        # 定义 AC1, AC3, AC5, AC7 为膨胀卷积层
        self.ac1 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=1, dilation=1)  # 膨胀率 1
        self.ac3 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=2, dilation=2)  # 膨胀率 3
        self.ac5 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=3, dilation=3)  # 膨胀率 5
        self.ac7 = nn.Conv2d(in_channel, out_channel, kernel_size=3, padding=4, dilation=4)  # 膨胀率 7
        self.conv1x1 = nn.Conv2d(out_channel*4, out_channel, kernel_size=1, stride=1, padding=0)
        self.conv3x3 = nn.Conv2d(out_channel, out_channel, kernel_size=1, stride=1, padding=0)

        # 平均池化层
        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        
        # 全连接层
        self.fc1 = nn.Linear(out_channel, 256)
        self.fc2 = nn.Linear(256, out_channel)

        self.GraphConv = GraphConv(out_channel)
        
    def forward(self, l, s):
        s = F.interpolate(s, size=l.size()[2:], mode='bilinear')
        x = l + s
        x1 = F.relu(self.ac1(x))
        x2 = F.relu(self.ac3(x))
        x3 = F.relu(self.ac5(x))
        x4 = F.relu(self.ac7(x))
        x_ = torch.cat((x1, x2, x3, x4), dim=1)
        # x_ = x1 + x2 + x3 + x4
        x_ = self.conv1x1(x_)

        Graph = self.GraphConv(x_)

        xa = self.avg_pool(x)
        xa = torch.flatten(xa, 1)
        
        xa = F.relu(self.fc1(xa))
        xa = self.fc2(xa)
        xa = F.softmax(xa, dim=1)
        xa = xa.unsqueeze(2).unsqueeze(3)
        
        output = Graph * xa
        output = self.conv3x3(output)
        output = output + x
        
        return output 


class Regression(nn.Module):
    def __init__(self):
        super(Regression, self).__init__()

        self.fusion1 = fusion(128,128)
        self.fusion2 = fusion(256,256)

        self.upsample_block1 = UpsampleBlock(in_channel=256, out_channel=128)
        self.upsample_block2 = UpsampleBlock(in_channel=512, out_channel=256)


        # self.edge1 = FocalModulation(128)
        # self.edge2 = FocalModulation(256)
        # self.edge3 = FocalModulation(512)




        self.res1 = nn.Sequential(
            nn.Conv2d(128, 64, 3, padding=1, dilation=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 1, 1),
            nn.ReLU()
        )
        # self.Translayer2_1 = BasicConv2d(512,256,1)
        # self.fam32_1 = decode(256,256,256) # AlignBlock(128) # decode(128,128,128)
        # self.Translayer3_1 = BasicConv2d(256,128,1)
        # self.fam43_1 = decode(128,128,128) # AlignBlock(64) # decode(64,64,64)
        self.c256 = BasicConv2d(512,256,1)
        self.decode1 = InteractiveModule(256,256)
        self.c128 = BasicConv2d(256,128,1)
        self.decode2 = InteractiveModule(128,128)

        self.multiscale = Multiscale(in_channel=128, out_channel=128, H=32,W=32)
        self.init_param()

    def forward(self, x1, x2, x3):

        # x1 = self.edge1(x1)
        # x2 = self.edge2(x2)
        # x3 = self.edge3(x3)
        # out1 = self.fam32_1(x2 , self.Translayer2_1(x3))
        # out = self.fam43_1(x1 , self.Translayer3_1(out1))
        # x3 = self.upsample_block2(x3)
        # out1 = self.fusion2(x3, x2)
        # out1 = self.upsample_block1(out1)
        # out = self.fusion1(out1, x1)
        out1 = self.decode1(x2 , self.c256(x3))
        out = self.decode2(x1 , self.c128(x2))

        out = self.multiscale(out, self.c128(out1))


        y = self.res1(out)

        return y


    def init_param(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight, std=0.01)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)



class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):

        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x




class Attention(nn.Module):
    def __init__(self, dim, num_heads=4, bias=False, ifBox=True):
        super(Attention, self).__init__()
        self.factor = num_heads
        self.ifBox = ifBox
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))        
        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        self.qkv_dwconv = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1, padding=1, groups=dim * 3, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

        self.attn1 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn2 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn3 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn4 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)

    def pad(self, x, factor):
        hw = x.shape[-1]
        t_pad = [0, 0] if hw % factor == 0 else [0, (hw // factor + 1) * factor - hw]
        x = F.pad(x, t_pad, 'constant', 0)
        return x, t_pad

    def unpad(self, x, t_pad):
        _, _, hw = x.shape
        return x[:, :, t_pad[0]:hw - t_pad[1]]

    def softmax_1(self, x, dim=-1):
        logit = x.exp()
        logit = logit / (logit.sum(dim, keepdim=True) + 1)
        return logit

    def normalize(self, x):
        mu = x.mean(-2, keepdim=True)
        sigma = x.var(-2, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5)  # * self.weight + self.bias

    def reshape_attn(self, q, k, v, h, w):
        b, c, hw = q.shape
        q = q.reshape(b, c, h, w)

        b, c, hw = k.shape
        k = k.reshape(b, c, h, w)

        b, c, hw = v.shape
        v = v.reshape(b, c, h, w)        

        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        _, _, C, _ = q.shape

        mask1 = torch.zeros(b, self.num_heads, C, C, device=q.device, requires_grad=False)
        mask2 = torch.zeros(b, self.num_heads, C, C, device=q.device, requires_grad=False)
        mask3 = torch.zeros(b, self.num_heads, C, C, device=q.device, requires_grad=False)
        mask4 = torch.zeros(b, self.num_heads, C, C, device=q.device, requires_grad=False)

        attn = (q @ k.transpose(-2, -1)) * self.temperature

        index = torch.topk(attn, k=int(C/2), dim=-1, largest=True)[1]
        mask1.scatter_(-1, index, 1.)
        attn1 = torch.where(mask1 > 0, attn, torch.full_like(attn, float('-inf')))

        index = torch.topk(attn, k=int(C*2/3), dim=-1, largest=True)[1]
        mask2.scatter_(-1, index, 1.)
        attn2 = torch.where(mask2 > 0, attn, torch.full_like(attn, float('-inf')))

        index = torch.topk(attn, k=int(C*3/4), dim=-1, largest=True)[1]
        mask3.scatter_(-1, index, 1.)
        attn3 = torch.where(mask3 > 0, attn, torch.full_like(attn, float('-inf')))

        index = torch.topk(attn, k=int(C*4/5), dim=-1, largest=True)[1]
        mask4.scatter_(-1, index, 1.)
        attn4 = torch.where(mask4 > 0, attn, torch.full_like(attn, float('-inf')))

        attn1 = attn1.softmax(dim=-1)
        attn2 = attn2.softmax(dim=-1)
        attn3 = attn3.softmax(dim=-1)
        attn4 = attn4.softmax(dim=-1)

        out1 = (attn1 @ v)
        out2 = (attn2 @ v)
        out3 = (attn3 @ v)
        out4 = (attn4 @ v)

        out = out1 * self.attn1 + out2 * self.attn2 + out3 * self.attn3 + out4 * self.attn4

        out = rearrange(out, 'b head c (h w) -> b (head c) (h w)', head=self.num_heads, h=h, w=w)
        return out

    def forward(self, x, h, w):
        b, n, c = x.shape

        x = x.reshape(b, c, h, w)
        x_sort, idx_h = x[:, :c // 2].sort(-2)
        x_sort, idx_w = x_sort.sort(-1)
        x[:, :c // 2] = x_sort
        qkv = self.qkv_dwconv(self.qkv(x))
        q1, k1, v = qkv.chunk(3, dim=1)  # b,c,x,x        
        v, idx = v.view(b, c, -1).sort(dim=-1)
        q1 = torch.gather(q1.view(b, c, -1), dim=2, index=idx)
        k1 = torch.gather(k1.view(b, c, -1), dim=2, index=idx)
        # q2 = torch.gather(q2.view(b, c, -1), dim=2, index=idx)
        # k2 = torch.gather(k2.view(b, c, -1), dim=2, index=idx)        
        out1 = self.reshape_attn(q1, k1, v, h, w)
        # out2 = self.reshape_attn(q2, k2, v, h, w)        
        out1 = torch.scatter(out1, 2, idx, out1).view(b, c, h, w)
        # out2 = torch.scatter(out2, 2, idx, out2).view(b, c, h, w)
        # out = out1 * out2
        out = self.project_out(out1)
        out_replace = out[:, :c // 2]
        out_replace = torch.scatter(out_replace, -1, idx_w, out_replace)
        out_replace = torch.scatter(out_replace, -2, idx_h, out_replace)
        out[:, :c // 2] = out_replace
        return out.reshape(b, n, c)


class GlobalLocalAttentionBlock(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0., sr_ratio=1):
        super(GlobalLocalAttentionBlock, self).__init__()
        self.attention = Attention(dim, num_heads)
        
        # self.local_conv_block = StripMultilevelConvolutionBlock(dim)

    def forward(self, x, H, W):

        # 全局注意力
        
        # x = x.reshape(B, C, -1).permute(0, 2, 1)
        global_out = self.attention(x, H, W)
        
        
        return global_out


class Block(nn.Module):

    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, sr_ratio=1):
        super().__init__()
        self.norm1 = norm_layer(dim)
        self.attn = GlobalLocalAttentionBlock(
            dim,
            num_heads=num_heads
        )
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
        self.drop_path1 = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.drop_path2 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x, H, W):
        x = x + self.drop_path1(self.attn(self.norm1(x), H, W))
        x = x + self.drop_path2(self.mlp(self.norm2(x)))

        return x



    

class Down_wt1(nn.Module):
    def __init__(self, in_ch, out_ch, enhancement_factor=1.5):
        super(Down_wt1, self).__init__()
        self.enhancement_factor = enhancement_factor
        # 定义离散小波变换（DWT）模块
        self.wt = DWTForward(J=1, mode='zero', wave='haar')

        self.conv_bn_relu1 = nn.Sequential(
            nn.Conv2d(in_ch , out_ch , kernel_size=1, stride=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

        self.conv_bn_relu3 = nn.Sequential(
            nn.Conv2d(in_ch * 3 , out_ch , kernel_size=1, stride=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def enhance_high_freq(self, cH, cV, cD):
        # 增强细节系数
        cH *= self.enhancement_factor
        cV *= self.enhancement_factor
        cD *= self.enhancement_factor
        return cH, cV, cD

    def forward(self, x):
        # 对输入张量进行一级小波变换，得到低频子带 yL 和高频子带 yH
        yl, yH = self.wt(x)  # torch.Size([1, 3, 64, 64])
        y_HL = yH[0][:, :, 0, ::]  # torch.Size([1, 3, 64, 64])
        y_LH = yH[0][:, :, 1, ::]
        y_HH = yH[0][:, :, 2, ::]

        # 增强高频子带
        y_HL, y_LH, y_HH = self.enhance_high_freq(y_HL, y_LH, y_HH)

        # 将低频子带和三个高频子带在通道维度上拼接起来
        yh = torch.cat([y_HL, y_LH, y_HH], dim=1)  # torch.Size([1, 12, 64, 64])
        # 通过卷积层、批归一化层和 ReLU 激活函数的顺序模块对拼接后的张量进行处理
        yl = self.conv_bn_relu1(yl)
        yh = self.conv_bn_relu3(yh)
        return yl, yh



class PatchEmbed(nn.Module):
    """ Image to Patch Embedding
    """

    def __init__(self, img_size=224, patch_size=16, in_chans=3, embed_dim=768,deep = 0):      #embed_dim表示输出的patch的向量维度
        super().__init__()
        img_size = to_2tuple(img_size)
        patch_size = to_2tuple(patch_size)
        self.img_size = img_size
        self.patch_size = patch_size
        self.deep = deep
        assert img_size[0] % patch_size[0] == 0 and img_size[1] % patch_size[1] == 0, \
            f"img_size {img_size} should be divided by patch_size {patch_size}."
        self.H, self.W = img_size[0] // patch_size[0], img_size[1] // patch_size[1]
        self.num_patches = self.H * self.W
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.dwt = Down_wt1(in_chans,embed_dim)
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, x):

        B, C, H, W = x.shape     #torch.Size([1, 3, 256, 256])
        if self.deep == 0:
            # x = self.proj(x)   # torch.Size([1, 128, 64, 64])
            # x1 = x.flatten(2)    #torch.Size([1, 128, 4096])
            # x2 = x1.transpose(1, 2)    #torch.Size([1, 4096, 128])
            x = self.proj(x).flatten(2).transpose(1, 2)    #torch.Size([1, 4096, 128])每个块（每个像素点）长度都是128
            y = x
        else:
            x, y = self.dwt(x)
            x = x.flatten(2).transpose(1, 2)
            y = y.flatten(2).transpose(1, 2)

        x = self.norm(x)
        y = self.norm(y)
        H, W = H // self.patch_size[0], W // self.patch_size[1]
        return x ,y ,(H, W)


# borrow from PVT https://github.com/whai362/PVT.git
class PyramidVisionTransformer(nn.Module):
    def __init__(self, img_size=224, patch_size=16, in_chans=3, num_classes=1000, embed_dims=[64, 128, 256, 512],
                 num_heads=[1, 2, 4, 8], mlp_ratios=[4, 4, 4, 4], qkv_bias=False, qk_scale=None, drop_rate=0.,
                 attn_drop_rate=0., drop_path_rate=0., norm_layer=nn.LayerNorm,
                 depths=[3, 4, 6, 3], sr_ratios=[8, 4, 2, 1], block_cls=Block):
        super().__init__()
        self.num_classes = num_classes
        self.depths = depths

        # patch_embed
        self.patch_embeds = nn.ModuleList()       #这四行创建模型中各个模块的列表
        self.pos_embeds = nn.ParameterList()
        self.pos_drops = nn.ModuleList()
        self.blocks = nn.ModuleList()

        for i in range(len(depths)):        #使用循环来构建PatchEmbed模块和相关位置嵌入和Dropout操作
            if i == 0:
                self.patch_embeds.append(PatchEmbed(img_size, patch_size, in_chans, embed_dims[i],i))
            else:
                self.patch_embeds.append(
                    PatchEmbed(img_size // patch_size // 2 ** (i - 1), 2, embed_dims[i - 1], embed_dims[i],i))      #深度越深，图像越小
            patch_num = self.patch_embeds[-1].num_patches + 1 if i == len(embed_dims) - 1 else self.patch_embeds[         #self.patch_embeds[-1]表示前一个PathEnbed实例
                -1].num_patches
            self.pos_embeds.append(nn.Parameter(torch.zeros(1, patch_num, embed_dims[i])))   #代码使用 nn.Parameter 函数将零张量转换为可训练的模型参数
            self.pos_drops.append(nn.Dropout(p=drop_rate))

        #dpr 列表的长度等于 sum(depths)，即所有层的深度之和。每个层都将有一个对应的元素来表示该层的随机深度衰减率。
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]  # stochastic depth decay rule和drop有关训练时随即丢弃某些层

        cur = 0
        for k in range(len(depths)):
            _block = nn.ModuleList([
                block_cls(
                    dim=embed_dims[k], num_heads=num_heads[k], mlp_ratio=mlp_ratios[k], qkv_bias=qkv_bias,
                    qk_scale=qk_scale,
                    drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[cur + i], norm_layer=norm_layer,
                    sr_ratio=sr_ratios[k]
                    )
                for i in range(depths[k])])
            self.blocks.append(_block)
            cur += depths[k]

        self.norm = norm_layer(embed_dims[-1])

        # cls_token
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dims[-1]))

        # classification head
        self.head = nn.Linear(embed_dims[-1], num_classes) if num_classes > 0 else nn.Identity()

        # init weights
        for pos_emb in self.pos_embeds:
            trunc_normal_(pos_emb, std=.02)
        self.apply(self._init_weights)     #apply对各子模块进行初始化

    def reset_drop_path(self, drop_path_rate):
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(self.depths))]
        cur = 0
        for k in range(len(self.depths)):
            for i in range(self.depths[k]):
                self.blocks[k][i].drop_path.drop_prob = dpr[cur + i]
            cur += self.depths[k]

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    @torch.jit.ignore
    def no_weight_decay(self):
        return {'cls_token'}

    def get_classifier(self):
        return self.head

    def reset_classifier(self, num_classes, global_pool=''):
        self.num_classes = num_classes
        self.head = nn.Linear(self.embed_dim, num_classes) if num_classes > 0 else nn.Identity()

    def forward_features(self, x):
        B = x.shape[0]
        for i in range(len(self.depths)):
            x, (H, W) = self.patch_embeds[i](x)
            if i == len(self.depths) - 1:
                cls_tokens = self.cls_token.expand(B, -1, -1)
                x = torch.cat((cls_tokens, x), dim=1)
            x = x + self.pos_embeds[i]
            x = self.pos_drops[i](x)
            for blk in self.blocks[i]:
                x = blk(x, H, W)
            if i < len(self.depths) - 1:
                x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        x = self.norm(x)
        return x[:, 0]

    def forward(self, x):
        x = self.forward_features(x)
        x = self.head(x)

        return x


# PEG  from https://arxiv.org/abs/2102.10882
class PosCNN(nn.Module):
    def __init__(self, in_chans, embed_dim, i,  s=1):
        super(PosCNN, self).__init__()
        self.proj = nn.Sequential(nn.Conv2d(in_chans, embed_dim, 3, s, 1, bias=True, groups=embed_dim), )
        self.conv1 = nn.Conv2d(int(in_chans * (1 / 4)), int(embed_dim * (1 / 4)), 3, s, 1, bias=True)  #groups=int(in_chans * 1 / 4)
        self.conv2 = nn.Conv2d(int(in_chans - in_chans*(1/4)), int(embed_dim - embed_dim*(1/4)), 3, s, 1, bias=True)  #groups= int(in_chans - in_chans*(1/4))

        self.s = s
        self.i = i

    def forward(self, x, H, W):
        B, N, C = x.shape
        feat_token = x    #将x给特征标记
        # feat_token_y = y
        cnn_feat = feat_token.transpose(1, 2).view(B, C, H, W)    #torch.Size([1, 128, 4096])    [torch.Size([1, 128, 64, 64])]
        if self.s == 1: 
            x = self.proj(cnn_feat) + cnn_feat       #对图像特征进行投影，并与图像特征 cnn_feat 相加
            # y = self.proj(feat_token_y) + feat_token_y
        x = x.flatten(2).transpose(1, 2)     #torch.Size([1, 4096, 128])
        # y = y.flatten(2).transpose(1, 2)
        return x

    def no_weight_decay(self):
        return ['proj.%d.weight' % i for i in range(4)]

    


class Gradients(nn.Module):
    def __init__(self):
        super(Gradients, self).__init__()
        self.Relu = nn.ReLU()
    def forward(self, inputs):
        # Enable gradient tracking for the inputs
        inputs.requires_grad_(True)
     
    
        # Compute gradients of the input tensor with respect to itself
        gradients_alpha = torch.autograd.grad(
            outputs=inputs,
            inputs=inputs,
            grad_outputs=torch.ones_like(inputs),
            create_graph=True,
            retain_graph=True,
            only_inputs=True
        )[0]

        # Reduce mean across the last three dimensions
        a = gradients_alpha.mean(dim=(-1, -2, -3), keepdim=True)

        return a
    


    

class AdaptiveHierarchicalNormalization(nn.Module):
    def __init__(self, num_features, eps=1e-5):
        super(AdaptiveHierarchicalNormalization, self).__init__()

        # 局部归一化（BatchNorm）
        self.local_bn = nn.BatchNorm2d(num_features, eps=eps)

        # **修改 LayerNorm 为 InstanceNorm**
        self.global_ln = nn.InstanceNorm2d(num_features, affine=True)  # **修正错误**

        # 自适应权重
        self.lambda_param = nn.Parameter(torch.tensor(0.5))

    def forward(self, x):
        local_norm = self.local_bn(x)
        global_norm = self.global_ln(x)  # **修正错误**

        norm_x = self.lambda_param * local_norm + (1 - self.lambda_param) * global_norm
        return norm_x
    


class NormalizedFeatureFusion(nn.Module):
    def __init__(self, feature_dim, use_ahn=True, lambda_learnable=True):
        """
        改进后的归一化特征融合模块
        :param feature_dim: 输入特征的通道数
        :param use_ahn: 是否使用 Adaptive Hierarchical Normalization 归一化
        :param lambda_learnable: 是否使用可学习融合参数
        """
        super(NormalizedFeatureFusion, self).__init__()
        self.use_ahn = use_ahn

        # 选择 Adaptive Hierarchical Normalization 还是 BatchNorm/L2 Norm
        if use_ahn:
            self.ahn = AdaptiveHierarchicalNormalization(feature_dim)
        else:
            self.norm_x = nn.BatchNorm2d(feature_dim)
            self.norm_y = nn.BatchNorm2d(feature_dim)

        # 可学习融合权重
        if lambda_learnable:
            self.lambda_factor = nn.Parameter(torch.tensor(0.5))  # 初始化融合比例
        else:
            self.lambda_factor = 0.5  # 固定融合比例

        # 1x1 卷积用于特征变换
        self.conv1x1 = nn.Conv2d(feature_dim, feature_dim, kernel_size=1)

    def forward(self, x, y):
        """
        :param x: 输入特征张量 (batch_size, C, H, W)
        :param y: 另一个输入特征张量 (batch_size, C, H, W)
        :return: 融合后的特征
        """
        # **Step 1: 归一化**
        if self.use_ahn:
            x = self.ahn(x)
            y = self.ahn(y)
        else:
            x = self.norm_x(x)
            y = self.norm_y(y)

        # **Step 2: 自适应融合**
        fusion_weight = torch.sigmoid(self.lambda_factor)  # 确保权重在 0-1 之间
        fused_feature = fusion_weight * x + (1 - fusion_weight) * y

        # **Step 3: 1x1 卷积增强特征**
        fused_feature = self.conv1x1(fused_feature)
        fused_feature = F.relu(fused_feature)  # ReLU 激活

        return fused_feature

class CPVTV2(PyramidVisionTransformer):
    """
    CPVT-based Pyramid Vision Transformer.
    Uses Position Encoding Generator (PEG) instead of fixed positional embeddings.
    Removes class token for improved performance on segmentation and detection tasks.
    """
    def __init__(self, img_size=224, patch_size=4, in_chans=3, num_classes=1000, 
                 embed_dims=[64, 128, 256, 512], num_heads=[1, 2, 4, 8], 
                 mlp_ratios=[4, 4, 4, 4], qkv_bias=False, qk_scale=None, 
                 drop_rate=0., attn_drop_rate=0., drop_path_rate=0., 
                 norm_layer=nn.LayerNorm, depths=[3, 4, 6, 3], sr_ratios=[8, 4, 2, 1], 
                 block_cls=Block):
        super(CPVTV2, self).__init__(img_size, patch_size, in_chans, num_classes, 
                                     embed_dims, num_heads, mlp_ratios, qkv_bias, 
                                     qk_scale, drop_rate, attn_drop_rate, drop_path_rate, 
                                     norm_layer, depths, sr_ratios, block_cls)

        # 移除固定的位置编码和分类 token
        del self.pos_embeds
        del self.cls_token

        # 位置编码模块（Positional Encoding Generator, PEG）
        self.pos_block = nn.ModuleList(
            [PosCNN(embed_dim, embed_dim, i) for i, embed_dim in enumerate(embed_dims)]
        )

        # 归一化层 (Adaptive Hierarchical Normalization)
        self.ahn_x = nn.ModuleList([AdaptiveHierarchicalNormalization(embed_dim) for embed_dim in embed_dims])
        self.ahn_y = nn.ModuleList([AdaptiveHierarchicalNormalization(embed_dim) for embed_dim in embed_dims])

        # 其他模块
        self.regression = Regression()

        # ⚠️ 这里不直接定义 feature_dim，而是后续根据 i 选择合适的通道数
        self.fusion_modules = nn.ModuleList(
            [NormalizedFeatureFusion(feature_dim=embed_dim) for embed_dim in embed_dims]
        )

        self.apply(self._init_weights)

    def forward_features(self, x):
        outputs = []  # 存储每个阶段的输出

        B = x.shape[0]  # 批次大小

        for i in range(len(self.depths)):
            # 获取 Patch Embedding 结果
            x, y, (H, W) = self.patch_embeds[i](x)  # x, y -> [B, N, C]  (N = H * W)

            # 位置编码
            x = self.pos_drops[i](x)
            y = self.pos_drops[i](y)

            # Transformer 块
            for j, blk in enumerate(self.blocks[i]):
                x = blk(x, H, W)
                y = blk(y, H, W)
                if j == 0:
                    x = self.pos_block[i](x, H, W)
                    y = self.pos_block[i](y, H, W)

            # 变换为 CNN 格式 [B, C, H, W]
            x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
            y = y.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()


            # ⚠️ 根据 i 选择合适的 fusion 模块
            grad_x_ = self.fusion_modules[i](x, y)

            outputs.append(grad_x_)

        return outputs




        return outputs

    def forward(self, x):
        x = self.forward_features(x)
        mu = self.regression(x[1], x[2], x[3])
        B, C, H, W = mu.size()
        mu_sum = mu.view([B, -1]).sum(1).unsqueeze(1).unsqueeze(2).unsqueeze(3)
        mu_normed = mu / (mu_sum + 1e-6)
        return mu, mu_normed


class PCPVT(CPVTV2):
    def __init__(self, img_size=224, patch_size=4, in_chans=3, num_classes=1000, embed_dims=[64, 128, 256],
                 num_heads=[1, 2, 4], mlp_ratios=[4, 4, 4], qkv_bias=False, qk_scale=None, drop_rate=0.,
                 attn_drop_rate=0., drop_path_rate=0., norm_layer=nn.LayerNorm,
                 depths=[4, 4, 4], sr_ratios=[4, 2, 1], block_cls=Block):
        super(PCPVT, self).__init__(img_size, patch_size, in_chans, num_classes, embed_dims, num_heads,
                                    mlp_ratios, qkv_bias, qk_scale, drop_rate, attn_drop_rate, drop_path_rate,
                                    norm_layer, depths, sr_ratios, block_cls)


class FSGformer(PCPVT):
    """
    alias Twins-SVT
    """
    def __init__(self, img_size=224, patch_size=4, in_chans=3, num_classes=1000, embed_dims=[64, 128, 256],
                 num_heads=[1, 2, 4], mlp_ratios=[4, 4, 4], qkv_bias=False, qk_scale=None, drop_rate=0.,
                 attn_drop_rate=0., drop_path_rate=0., norm_layer=nn.LayerNorm,
                 depths=[4, 4, 4], sr_ratios=[4, 2, 1], block_cls=Block):
        super(FSGformer, self).__init__(img_size, patch_size, in_chans, num_classes, embed_dims, num_heads,
                                     mlp_ratios, qkv_bias, qk_scale, drop_rate, attn_drop_rate, drop_path_rate,
                                     norm_layer, depths, sr_ratios, block_cls)
        del self.blocks
 
        # transformer encoder
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]  # stochastic depth decay rule
        cur = 0
        self.blocks = nn.ModuleList()
        for k in range(len(depths)):
            _block = nn.ModuleList([block_cls(
                dim=embed_dims[k], num_heads=num_heads[k], mlp_ratio=mlp_ratios[k], qkv_bias=qkv_bias,
                qk_scale=qk_scale,
                drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[cur + i], norm_layer=norm_layer,
                sr_ratio=sr_ratios[k],) for i in range(depths[k])])
            self.blocks.append(_block)
            cur += depths[k]
        self.apply(self._init_weights)


def _conv_filter(state_dict, patch_size=16):
    """ convert patch embedding weight from manual patchify + linear proj to conv"""
    out_dict = {}
    for k, v in state_dict.items():
        if 'patch_embed.proj.weight' in k:
            v = v.reshape((v.shape[0], 3, patch_size, patch_size))
        out_dict[k] = v

    return out_dict

@register_model
def alt_gvt_small(pretrained=False, **kwargs):
    model = FSGformer(
        patch_size=4, embed_dims=[64, 128, 256, 512], num_heads=[2, 4, 8, 16], mlp_ratios=[4, 4, 4, 4], qkv_bias=True,
        norm_layer=partial(nn.LayerNorm, eps=1e-6), depths=[2, 2, 10, 4], wss=[7, 7, 7, 7], sr_ratios=[8, 4, 2, 1],
        **kwargs)
    model.default_cfg = _cfg()
    return model


@register_model
def alt_gvt_base(pretrained=True, **kwargs):
    model = FSGformer(
        patch_size=4, embed_dims=[96, 192, 384, 768], num_heads=[3, 6, 12, 24], mlp_ratios=[4, 4, 4, 4], qkv_bias=True,
        norm_layer=partial(nn.LayerNorm, eps=1e-6), depths=[2, 2, 18, 2], wss=[7, 7, 7, 7], sr_ratios=[8, 4, 2, 1],
        **kwargs)

    model.default_cfg = _cfg()
    return model


@register_model
def alt_gvt_large(pretrained=True,**kwargs):
    model = FSGformer(
        patch_size=4, embed_dims=[64, 128, 256, 512], num_heads=[4, 8, 16, 32], mlp_ratios=[4, 4, 4, 4],
        qkv_bias=True,
        norm_layer=partial(nn.LayerNorm, eps=1e-6), depths=[2, 2, 10, 4], sr_ratios=[8, 4, 2, 1],
        **kwargs)
    model.default_cfg = _cfg()
    if pretrained:
        '''download from https://github.com/Meituan-AutoML/Twins/alt_gvt_large.pth'''
        checkpoint = torch.load(r'C:\Users\ming\Desktop\code\FSGformer(two)\alt_gvt_small.pth') # todo pass path as argument
        model.load_state_dict(checkpoint, strict=False)
        print("load transformer pretrained")
    return model
from fvcore.nn import FlopCountAnalysis
if __name__ == '__main__':
    model = alt_gvt_large().cuda()
    x = torch.ones(1, 3, 256, 256).cuda() 
    mu, mu_norm = model(x)
    print(mu.size(), mu_norm.size())
    # print(model)
    # summary(model,input_size=(3,256,256))
    flops = FlopCountAnalysis(model, x)
    print(f'计算量 (FLOPs): {flops.total()}')
    # print(torch.cuda.is_available())